#!/bin/bash

# backup_full.sh - Script de backup con parametros de origen y destino

# Ayuda
if [[ "$1" == "-help" ]]; then
  echo "Uso: $0 <directorio_origen> <directorio_destino>"
  echo "Ejemplo: $0 /var/log /backup_dir"
  echo "El backup se guardara como <nombre>_bkp_YYYYMMDD.tar.gz"
  exit 1
fi

# Validar parametros
if [[ -z "$1" || -z "$2" ]]; then
  echo "ERROR - Faltan parametros. Usar -help para ayuda."
  exit 1
fi

# Variables
ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"

# Validar que el origen existe
if [[ ! -d "$ORIGEN" ]]; then
  echo "ERROR - El directorio origen '$ORIGEN' no existe."
  exit 3
fi

# Validar que el destino existe
if [[ ! -d "$DESTINO" ]]; then
  echo "ERROR - El directorio destino '$DESTINO' no existe."
  exit 4
fi

# Ejecutar backup
tar -czf "$ARCHIVO" "$ORIGEN"

# Confirmacion
if [[ $? -eq 0 ]]; then
  echo "Backup exitoso: $ARCHIVO"
else
  echo "Error durante el backup."
fi

exit 0

